const mongoose = require("mongoose");
const Schema = mongoose.Schema;
const bookSchema = new Schema({
	model: {
		type: String,
		require: true,
	},
	name: {
		type: String,
		require: true,
	},
	mobileno: {
		type: String,
		require: true,
	},
	adharno: {
		type: String,
		require: true,
	},
	licienceno: {
		type: String,
		require: true,
	},
	place: {
		type: String,
		require: true,
	},
});

module.exports = mongoose.model("books", bookSchema);
