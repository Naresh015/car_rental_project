const express = require("express");
const router = express.Router();
const book = require("../model/book");

router.post("/postdata", async (req, res) => {
	let books;
	try {
		books = new book({
			model: req.body.send.model,
			name: req.body.send.name,
			mobileno: req.body.send.mobileno,
			adharno: req.body.send.adharno,
			licienceno: req.body.send.licienceno,
			place: req.body.send.place,
		});
		await books.save();
	} catch (err) {
		console.log(err);
	}
	if (!books) {
		return res.status(500).json({ msg: "Someting went wrong" });
	}
	return res.status(200).json({ books });
});

module.exports = router;
