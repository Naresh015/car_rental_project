import React from "react";
import "./sidebar.css";
import { Link } from "react-router-dom";
const Sidebar = () => {
	return (
		<div>
			<div className="sidebar">
				<Link to="/" className="a">
					HOME
				</Link>
				<Link to="/" className="a">
					HISTORY
				</Link>
				<Link to="/" className="a">
					STATUS
				</Link>
			</div>
		</div>
	);
};
export default Sidebar;
