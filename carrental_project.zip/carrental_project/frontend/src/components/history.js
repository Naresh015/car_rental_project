import React from "react";
const History = () => {
	return (
		<div className="container-fluid">
			<div>
				<h3>PREVIOUS CUSTOMERS RATING</h3>
				<table className="table table-striped">
					<thead>
						<tr>
							<th>NAME</th>
							<th>CAR MODEL</th>
							<th>REVIEW</th>
						</tr>
					</thead>
					<tbody>
						<tr>
							<td>Naresh</td>
							<td>Mahindra Thar</td>
							<td>Exellent Vechile and it is in Better Condition</td>
						</tr>
						<tr>
							<td>Bapi raju</td>
							<td>Mahindra Scorpio N</td>
							<td>Good</td>
						</tr>
						<tr>
							<td>Udhy Kiran</td>
							<td>Maruthi Suzuki Swift</td>
							<td>Nice Vechile</td>
						</tr>
						<tr>
							<td>Dinesh</td>
							<td>Mahindra Bolero</td>
							<td>Easy Booking Process</td>
						</tr>
						<tr>
							<td>Lakshmi narayana</td>
							<td>Mercedes-Benz G-Class</td>
							<td>Exellent Vechile</td>
						</tr>
						<tr>
							<td>Durga prasad</td>
							<td>Toyota Fortuner</td>
							<td>Super Service</td>
						</tr>
						<tr>
							<td>Charan</td>
							<td>Maruthi Suzuki Breeza</td>
							<td>Better Condition</td>
						</tr>
						<tr>
							<td>Aditya</td>
							<td>Mahindra Thar</td>
							<td>Better Condition </td>
						</tr>
						<tr>
							<td>Lokesh</td>
							<td>Tata Altroz</td>
							<td>Exellent Vechile and Good to Go Long Drives</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	);
};
export default History;
