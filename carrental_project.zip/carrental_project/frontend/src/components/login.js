import "bootstrap/dist/css/bootstrap.css";
import { Link } from "react-router-dom";

import "./home.css";
const Login = () => {
	return (
		<div id="body1">
			<div class="container fluid">
				<div class="row">
					<div class="col-md-3">
						<form action="/action_page.php" className="admin">
							<h2 id="ad">USER LOGIN</h2>
							<div class="form-group">
								<input
									type="text"
									class="form-control"
									placeholder="Enter user id"
								></input>
							</div>
							<br></br>
							<div class="form-group">
								<input
									type="password"
									class="form-control"
									placeholder="Enter Password"
								></input>
							</div>
							<br></br>
							<div class="row">
								<div class="col-md-6">
									<input
										type="reset"
										class="form-control "
										name=""
										value="RESET ALL"
									></input>
								</div>
								<div class="col-md-6 ls">
									<Link to="/home" class="l">
										LOGIN
									</Link>
								</div>
							</div>
						</form>
					</div>
					<div className="col-md-1"></div>
					<div class="col-md-3">
						<form action="/action_page.php" className="admin">
							<h2 id="us">OWNER LOGIN</h2>
							<div class="form-group">
								<input
									type="text"
									class="form-control"
									placeholder="Enter user id"
								></input>
							</div>
							<br></br>
							<div class="form-group">
								<input
									type="password"
									class="form-control"
									placeholder="Enter Password"
								></input>
							</div>
							<br></br>
							<div class="row">
								<div class="col-md-6">
									<input
										type="reset"
										class="form-control "
										name=""
										value="RESET ALL"
									></input>
								</div>
								<div class="col-md-6 ls">
									<Link to="/home" class="l">
										LOGIN
									</Link>
								</div>
							</div>
						</form>
					</div>
					<div className="col-md-1"></div>
					<div class="col-md-3">
						<form action="/action_page.php" className="admin">
							<h2 id="ad">ADMIN LOGIN</h2>
							<div class="form-group">
								<input
									type="text"
									class="form-control"
									placeholder="Enter user id"
								></input>
							</div>
							<br></br>
							<div class="form-group">
								<input
									type="password"
									class="form-control"
									placeholder="Enter Password"
								></input>
							</div>
							<br></br>
							<div class="row">
								<div class="col-md-6">
									<input
										type="reset"
										class="form-control "
										name=""
										value="RESET ALL"
									></input>
								</div>
								<div class="col-md-6 ls">
									<Link to="/home" class="l">
										LOGIN
									</Link>
								</div>
							</div>
						</form>
					</div>
				</div>
				<div className="row b21"></div>
			</div>
		</div>
	);
};
export default Login;
