import "./home.css";
import React from "react";
import { Link } from "react-router-dom";
import "bootstrap/dist/css/bootstrap.css";
import Container from "react-bootstrap/Container";
import { Navbar, Nav, NavItem } from "react-bootstrap";
import Img from "./l1.jpg";
function Header() {
	return (
		<Navbar collapseOnSelect sticky="top" expand="md" bg="dark" variant="dark">
			<Container>
				<Navbar.Brand href="#home">
					<img
						className="l1"
						id="cdimg"
						style={{ height: "60px", width: "60px", borderRadius: "50%" }}
						src={Img}
						alt="image"
					/>
				</Navbar.Brand>
				<Navbar.Toggle aria-controls="responsive-navbar-nav" />
				<Navbar.Collapse id="responsive-navbar-nav">
					<Nav className="me-auto Nav">
						<Nav.Link href="/home" className="Nav">
							<h5>Home</h5>
						</Nav.Link>
						<Nav.Link href="/history" className="Nav">
							<h5>HISTORY</h5>
						</Nav.Link>
						<Nav.Link href="/status" className="Nav">
							<h5>VIEW STATUS</h5>
						</Nav.Link>
						<Nav.Link href="/privacy" className="Nav">
							<h5>PRIVACY POLICY</h5>
						</Nav.Link>
					</Nav>
					<Nav>
						<div class="dropdown">
							<span className="a1">REPORT</span>
							<div class="dropdown-content">
								<Link to="/about">About</Link>
								<br />
								<Link to="/contact">Contact Us</Link>
								<br />
								<Link to="/login">Logout</Link>
							</div>
						</div>
					</Nav>
				</Navbar.Collapse>
			</Container>
		</Navbar>
	);
}
export default Header;
