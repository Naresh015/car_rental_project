import React, { useState } from "react";
// import "./booking.css";
import axios from "axios";

const Bookinghis = () => {
	const [send, setSend] = useState({
		model: "",
		name: "",
		mobileno: "",
		adharno: "",
		licienceno: "",
		place: "",
	});
	const handleChange = (e) => {
		setSend((prevState) => ({
			...prevState,
			[e.target.name]: e.target.value,
		}));
	};
	const postSubmit = (e) => {
		e.preventDefault();
		axios.post("http://localhost:5000/postdata", { send });
		console.log(send);
		alert("Success");
	};
	return (
		<div className="container-fluid color">
			<div className="row">
				<div className="col-md-3"></div>
				<div className="col-md-6 color1">
					<form action="action_page.php">
						<div className="row">
							<h2>BOOKING PORTAL</h2>
						</div>
						<div className="form-group">
							<div className="row">
								<div className="col-md-2">Model Of Car : </div>
								<div className="col-md-9">
									<input
										type="text"
										className="form-control"
										name="model"
										placeholder="Enter The Model You Want To Book"
										onChange={handleChange}
									/>
								</div>
							</div>
						</div>
						<br />
						<div className="form-group">
							<div className="row">
								<div className="col-md-2">NAME : </div>
								<div className="col-md-9">
									<input
										type="text"
										className="form-control"
										name="name"
										onChange={handleChange}
										placeholder="Enter Your Name"
									/>
								</div>
							</div>
						</div>
						<br />
						<div className="form-group">
							<div className="row">
								<div className="col-md-2">MOBILE NO: </div>
								<div className="col-md-9">
									<input
										type="text"
										className="form-control"
										name="mobileno"
										onChange={handleChange}
										placeholder="Enter Your Mobile Number"
									/>
								</div>
							</div>
						</div>
						<br />
						<div className="form-group">
							<div className="row">
								<div className="col-md-2">Adhar No: </div>
								<div className="col-md-9">
									<input
										type="text"
										className="form-control"
										name="adharno"
										onChange={handleChange}
										placeholder="Enter Your Adhar Number"
									/>
								</div>
							</div>
						</div>
						<br />
						<div className="form-group">
							<div className="row">
								<div className="col-md-2">Driving Licience : </div>
								<div className="col-md-9">
									<input
										type="text"
										className="form-control"
										name="licienceno"
										onChange={handleChange}
										placeholder="Enter Your Driving Licience"
									/>
								</div>
							</div>
						</div>
						<br />
						<div className="form-group">
							<div className="row">
								<div className="col-md-2">Occaution Place: </div>
								<div className="col-md-9">
									<input
										type="text"
										className="form-control"
										name="place"
										onChange={handleChange}
										placeholder="Enter the Occaution Place "
									/>
								</div>
							</div>
						</div>
						<br />
						<div class="row">
							<div className="col-md-2"></div>
							<div class="col-md-4">
								<input
									type="reset"
									class="form-control "
									name=""
									value="RESET ALL DATA"
								></input>
							</div>
							<div class="col-md-5">
								<button
									type="submit"
									onClick={postSubmit}
									className="btn btn-primary bbt"
								>
									Submit
								</button>
							</div>

							<div className="col-md-2"></div>
						</div>
					</form>
				</div>
			</div>
		</div>
	);
};
export default Bookinghis;
