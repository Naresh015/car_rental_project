import React from "react";
const About = () => {
	return (
		<div className="container-fluid abg">
			<div className="row">
				<ul>
					<li className="ab1">
						Welcome to our car rental website! We are a team of dedicated
						professionals who are passionate about providing the best possible
						car rental experience for our customers. Our mission is to make car
						rental as simple, easy, and convenient as possible, whether you're
						traveling for business or pleasure.
					</li>
					<li className="ab1">
						We understand that renting a car can sometimes be a stressful and
						daunting experience, which is why we've made it our goal to provide
						exceptional customer service and support to help make your rental
						experience as smooth and hassle-free as possible. Our team is made
						up of knowledgeable experts who are always happy to answer any
						questions you may have and help you find the perfect car for your
						needs.
					</li>
					<li className="ab1">
						We offer a wide range of rental cars to suit any budget or
						preference, from compact cars to luxury vehicles, and everything in
						between. Whether you need a car for a day, a week, or longer, we've
						got you covered. Plus, with our easy online booking system, you can
						reserve your rental car quickly and easily from the comfort of your
						own home.
					</li>
					<li className="ab1">
						At our car rental website, we take pride in providing high-quality,
						reliable rental cars at affordable prices. We believe that everyone
						should have access to safe and reliable transportation, which is why
						we strive to offer some of the most competitive rates in the
						industry.
					</li>
					<li className="ab1">
						So why choose us for your next car rental? Because we're committed
						to making your rental experience as easy and stress-free as
						possible, from start to finish. With our friendly customer service,
						wide selection of rental cars, and affordable prices, you can rest
						assured that you're getting the best possible car rental experience.
					</li>
				</ul>
			</div>
		</div>
	);
};
export default About;
