import React from "react";

export default function Status() {
	return (
		<div className="container-fluid">
			<h2>STATUS OF A VEHICLES</h2>
			<div className="row">
				<h4 id="sh">ULTRA LUXURIES CARS</h4>
				<div className="col-md-1"></div>
				<div className="col-md-3 d1">
					<h5>TOTAL VEHICLES</h5>
					<h6>180</h6>
				</div>
				<div className="col-md-1 "></div>
				<div className="col-md-3 d2">
					<h5>AVAILABLE VEHICLES</h5>
					<h6>30</h6>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 d3">
					<h5> AVAILABLE ON NEXT WEEK</h5>
					<h6>20</h6>
				</div>
			</div>
			<div className="row">
				<h4 id="sh">LUXURIES CARS</h4>
				<div className="col-md-1"></div>
				<div className="col-md-3 d1">
					<h5>TOTAL VEHICLES</h5>
					<h6>320</h6>
				</div>
				<div className="col-md-1 "></div>
				<div className="col-md-3 d2">
					<h5>AVAILABLE VEHICLES</h5>
					<h6>80</h6>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 d3">
					<h5> AVAILABLE ON NEXT WEEK</h5>
					<h6>40</h6>
				</div>
			</div>
			<div className="row">
				<h4 id="sh">ORDINARY CARS</h4>
				<div className="col-md-1"></div>
				<div className="col-md-3 d1">
					<h5>TOTAL VEHICLES</h5>
					<h6>1320</h6>
				</div>
				<div className="col-md-1 "></div>
				<div className="col-md-3 d2">
					<h5>AVAILABLE VEHICLES</h5>
					<h6>220</h6>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 d3">
					<h5> AVAILABLE ON NEXT WEEK</h5>
					<h6>420</h6>
				</div>
			</div>
		</div>
	);
}
