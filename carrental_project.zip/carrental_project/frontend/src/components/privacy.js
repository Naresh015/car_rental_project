import React from "react";
const Privacy = () => {
	return (
		<div className="container-fluid">
			<div className="row">
				<h3>This Website Strictly Follows This Guide Lines</h3>
				<ul>
					<li>
						At [company name], we take your privacy seriously. This Privacy
						Policy explains how we collect, use, and protect your personal
						information when you use our website [website URL] to rent a car or
						to learn about our services.
					</li>
					<li>
						Collection of Information We may collect personal information from
						you when you use our website or services. This information may
						include your name, address, email address, phone number, driver’s
						license information, credit card information, and other information
						that you provide to us. We may also collect information about your
						usage of our website, including your IP address, browser type, and
						pages viewed.
					</li>
					<li>
						Use of Information We use the information we collect to provide you
						with the car rental services you requested, to process payments, and
						to communicate with you about your rental. We may also use your
						information to send you promotional emails about our services or
						special offers, but you can opt out of receiving these emails at any
						time.
					</li>
					<li>
						Sharing of Information We may share your personal information with
						third-party service providers who help us provide our services, such
						as payment processors, car rental agencies, and marketing companies.
						We may also share your information with law enforcement agencies or
						other third parties when required by law or to protect our rights or
						property.
					</li>
					<li>
						Security of Information We take reasonable measures to protect your
						personal information from unauthorized access, disclosure, or
						misuse. We use secure servers and encryption technologies to protect
						your information during transmission and storage. However, we cannot
						guarantee the security of your information, and you should take
						steps to protect your own information, such as using strong
						passwords and not sharing your login information with others.
					</li>
					<li>
						Cookies and Other Tracking Technologies We may use cookies and other
						tracking technologies to collect information about your usage of our
						website. This information may include your IP address, browser type,
						and pages viewed. We use this information to improve our website and
						services and to personalize your experience on our website.
					</li>
				</ul>
			</div>
		</div>
	);
};
export default Privacy;
