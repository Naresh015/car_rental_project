import React from "react";
import { Link } from "react-router-dom";

import I1 from "./images/i1.jpg";
import I2 from "./images/i2.jpg";
import I3 from "./images/i3.jpg";
import I4 from "./images/i4.jpg";
import I5 from "./images/i5.jpg";
import I6 from "./images/i6.jpg";
import I7 from "./images/i7.jpg";
import I8 from "./images/i8.jpg";
import I9 from "./images/i9.jpg";
import I10 from "./images/i10.jpg";
import I11 from "./images/i11.jpg";
import I12 from "./images/i12.jpg";

const Home = () => {
	return (
		<div className="container">
			<div className="row hr">
				<h2>DashBoard</h2>
			</div>
			<div className="row">
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row ">
						<img src={I1} alt="img1" id="h" />
					</div>
					<div className="row">
						<h5>Mahindra Thar</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I2} alt="img1" />
					</div>
					<div className="row">
						<h5>Maruthi Suzuki Fronx</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $60/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I3} alt="img1" />
					</div>
					<div className="row">
						<h5>Maruthi Suzuki Swift</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $30/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
			</div>

			<div className="row">
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I4} alt="img1" />
					</div>
					<div className="row">
						<h5>Mahindra Scorpio N</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I5} alt="img1" />
					</div>
					<div className="row">
						<h5>Toyota Fortuner</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I6} alt="img1" />
					</div>
					<div className="row">
						<h5>Tata Harrier</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className="row">
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I7} alt="img1" />
					</div>
					<div className="row">
						<h5>Maruthi Suzuki Brezza</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I8} alt="img1" />
					</div>
					<div className="row">
						<h5>Mahindra XUV300</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I9} alt="img1" />
					</div>
					<div className="row">
						<h5>Toyota Innova Crysta</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div className="row">
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I10} alt="img1" />
					</div>
					<div className="row">
						<h5>Tata Altroz</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I11} alt="img1" />
					</div>
					<div className="row">
						<h5>Mahindra Bolero</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
				<div className="col-md-1"></div>
				<div className="col-md-3 b">
					<div className="row">
						<img src={I12} alt="img1" />
					</div>
					<div className="row">
						<h5>Mercedes-Benz G-Class</h5>
						<h6>Vehicle type : Diesel-5 seater</h6>
						<hr />
						<div className="row my-1">
							<div className="col-md-6">
								<h5>Price : $80/day</h5>
							</div>
							<div className="col-md-6">
								<Link to="/bookinghis">
									<button className="bt">Book Now</button>
								</Link>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	);
};
export default Home;
