import { Route, Routes } from "react-router-dom";
import "./App.css";
import Home from "./components/home";
import About from "./components/about";
import Contact from "./components/contact";
import Login from "./components/login";
import Header from "./components/header";
import Booking from "./components/bookinghis";
import History from "./components/history";
import Privacy from "./components/privacy";
import Status from "./components/status";
import Footer from "./components/footer";
function App() {
	return (
		<>
			<div className="App">
				<Header />

				<Routes>
					<Route path="/home" element={<Home />}></Route>
					<Route path="/about" element={<About />}></Route>
					<Route path="/contact" element={<Contact />}></Route>
					<Route path="/" element={<Login />}></Route>
					<Route path="/bookinghis" element={<Booking />} />
					<Route path="history" element={<History />} />
					<Route path="privacy" element={<Privacy />} />
					<Route path="status" element={<Status />} />
				</Routes>
				<Footer />
			</div>
		</>
	);
}

export default App;
